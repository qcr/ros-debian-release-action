/* Distributed under the OSI-approved BSD 3-Clause License.  See accompanying
   file Copyright.txt or https://cmake.org/licensing#kwsys for details.  */
#ifndef cmsys_testSystemtools_h
#define cmsys_testSystemtools_h

#define RUNTIME_OUTPUT_DIRECTORY "/docker_ws/cmake-3.20/Source/kwsys"

#define TEST_SYSTEMTOOLS_SOURCE_DIR "/docker_ws/cmake-3.20/Source/kwsys"
#define TEST_SYSTEMTOOLS_BINARY_DIR "/docker_ws/cmake-3.20/Source/kwsys"
/* #undef KWSYS_TEST_SYSTEMTOOLS_LONG_PATHS */

#endif
